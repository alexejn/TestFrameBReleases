//
//  TestFrameB.h
//  TestFrameB
//
//  Created by alexej_ne on 21.01.2020.
//  Copyright © 2020 BCS. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TestFrameB.
FOUNDATION_EXPORT double TestFrameBVersionNumber;

//! Project version string for TestFrameB.
FOUNDATION_EXPORT const unsigned char TestFrameBVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFrameB/PublicHeader.h>


